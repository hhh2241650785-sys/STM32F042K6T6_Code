/*
 * st7735_cfg.h  —— 标准库（StdPeriph）移植版配置
 *
 * 原 HAL 版这里 include 的是 CubeMX 生成的 main.h，并使用 hspi1 句柄、
 * GPIO_PIN_x 宏和 GPIOB 的 PB12~PB15 默认引脚。标准库工程里这些都不存在，
 * 且 STM32F042K6T6（LQFP32）根本没有 PB12~PB15，所以全部改成下面这样。
 */

#ifndef ST7735_CFG_H_
#define ST7735_CFG_H_

#include "stm32f0xx.h"          /* 标准库总头文件 */

/* 屏幕型号/方向：WaveShare 款 ST7735S 1.8" 128x160，与你的屏一致，保持这一行开启 */
/* #define ST7735_1_8_DEFAULT_ORIENTATION */
#define ST7735S_1_8_DEFAULT_ORIENTATION
/* #define ST7735_1_44_DEFAULT_ORIENTATION */
/* #define ST7735_MINI_DEFAULT_ORIENTATION */

/* SPI 固定使用 SPI1：SCK = PA5，MOSI = PA7（在 st7735.c 中初始化） */

/* 控制引脚：全部接在 GPIOA 上，标准库写法 GPIO_Pin_x
 * 接线与 lcd_st7735s 驱动一致：RES=PA2, DC=PA3, CS=PA4, BL=PA1 */
#define ST7735_RES_Pin          GPIO_Pin_2
#define ST7735_RES_GPIO_Port    GPIOA

#define ST7735_DC_Pin           GPIO_Pin_3
#define ST7735_DC_GPIO_Port     GPIOA

#define ST7735_CS_Pin           GPIO_Pin_4
#define ST7735_CS_GPIO_Port     GPIOA

#define ST7735_BL_Pin           GPIO_Pin_1
#define ST7735_BL_GPIO_Port     GPIOA

#endif /* ST7735_CFG_H_ */
