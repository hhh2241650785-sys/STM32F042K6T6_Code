#include "stm32f0xx.h"
#include "stm32f0xx_conf.h"
#include "stm32f0xx_rcc.h"
#include "stm32f0xx_gpio.h"

int main(void)
{
    while (1)
    {
        /* Main loop */
    }
}
