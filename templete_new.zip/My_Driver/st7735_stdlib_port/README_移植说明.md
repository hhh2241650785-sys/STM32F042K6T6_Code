# ST7735 驱动：HAL 版 → 标准库移植版说明

原版：ST7735_SPI_STM32_HAL（作者 Andriy Honcharenko），基于 HAL 库 + CubeMX。
本文件夹是把它移植到 **STM32F042K6T6 + 标准外设库 + Keil5** 之后的版本。

## 为什么原版不能直接用于标准库

原版底层调用的全是 HAL 接口，标准库工程里不存在，直接编译会报一堆未定义：

| 原版（HAL） | 移植后（标准库） |
|---|---|
| `HAL_SPI_Transmit(&hspi1, ...)` | 循环调用 `SPI_SendData8(SPI1, ...)` |
| `HAL_GPIO_WritePin(port, pin, ...)` | `GPIO_SetBits()` / `GPIO_ResetBits()` |
| `HAL_Delay(ms)` | 驱动内部的 `ST7735_DelayMs()`（粗略延时） |
| `SPI_HandleTypeDef hspi1`、cfg 里 include `main.h` | 删除；cfg 改 include `stm32f0xx.h` |
| SPI/GPIO 初始化靠 CubeMX 生成 | 已补进 `ST7735_GPIO_Init()`，`ST7735_Init()` 内部自动调用 |
| 默认引脚 GPIOB 的 PB12~PB15 | F042K6（LQFP32）没有这些脚，改为 GPIOA：RES=PA2、DC=PA3、CS=PA4、BL=PA1 |

DMA 选项（USE_SPI_DMA）已去掉，全部走查询发送，功能不受影响。

**没动的部分**：初始化命令表、全部绘图函数（画点/线/圆/三角/圆角矩形等）、
文字显示和 fonts.c 字库，与原版完全一致。

## 接线

| 屏幕 | STM32F042K6T6 |
|---|---|
| GND | GND |
| VCC | 3.3V |
| SCL | PA5 |
| SDA | PA7 |
| RST | PA2 |
| DC  | PA3 |
| CS  | PA4 |
| BLK | PA1 |

## 使用

把 5 个文件（st7735.c/h、st7735_cfg.h、fonts.c/h）加入 Keil 工程即可：

```c
#include "st7735.h"

int main(void)
{
    ST7735_Init();                                  /* 内部已含 GPIO + SPI1 初始化 */
    ST7735_FillScreen(ST7735_COLOR565(255, 0, 0));  /* 整屏红色验证 */
    ST7735_DrawString(10, 10, "Hello!", Font_11x18, 0xFFFF, 0x0000);

    while (1)
    {
    }
}
```

注意两点和我之前那份 lcd_st7735s 驱动的区别：
- 本驱动的 `ST7735_DrawImage()` 吃的是 **uint16_t 数组**（一个元素一个像素），
  转图时选 “RGB565, uint16_t 输出”；之前那份吃的是 uint8_t 字节数组。
- 本驱动 cfg 里选的是 WaveShare ST7735S 方向（X 偏移 2、Y 偏移 1、RGB 顺序）。
  若你的屏出现红蓝互换，把 st7735.h 中 ST7735S_1_8 段的
  `ST7735_MADCTL_RGB` 改成 `ST7735_MADCTL_BGR`；若有白边/错位，调 XSTART/YSTART。

状态：已完成代码移植与逐处核对（无 HAL 残留），未在真机上验证。
